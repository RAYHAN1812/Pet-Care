package com.example.petty

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
